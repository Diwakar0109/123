try:
    from pgmpy.models import DiscreteBayesianNetwork
    from pgmpy.factors.discrete import TabularCPD
    from pgmpy.inference import VariableElimination
except ImportError:
    print("pgmpy library not found. Please install it using: pip install pgmpy")
    exit()

def main():
    try:
        # --- Get User Input for Probabilities ---
        print("Enter probabilities for the Bayesian Network (0-1):")
        ah = float(input("P(Attendance=High): "))
        pa = float(input("P(Participation=Active): "))
        shh = float(input("P(Success|Attendance=High, Participation=Active): "))
        shp = float(input("P(Success|Attendance=High, Participation=Passive): "))
        slh = float(input("P(Success|Attendance=Low, Participation=Active): "))
        slp = float(input("P(Success|Attendance=Low, Participation=Passive): "))

        # --- Define the Bayesian Network Structure ---
        # Two parent nodes (Attendance, Participation) pointing to one child (CourseSuccess)
        model = DiscreteBayesianNetwork([("Attendance", "CourseSuccess"),
                                         ("Participation", "CourseSuccess")])

        # --- Define the Conditional Probability Distributions (CPDs) ---
        cpd_attendance = TabularCPD("Attendance", 2, [[ah], [1 - ah]],
                                    state_names={'Attendance': ['High', 'Low']})
        
        cpd_participation = TabularCPD("Participation", 2, [[pa], [1 - pa]],
                                       state_names={'Participation': ['Active', 'Passive']})
        
        cpd_success = TabularCPD("CourseSuccess", 2,
                               [[shh, shp, slh, slp],
                                [1 - shh, 1 - shp, 1 - slh, 1 - slp]],
                               evidence=["Attendance", "Participation"],
                               evidence_card=[2, 2],
                               state_names={'CourseSuccess': ['Yes', 'No'],
                                            'Attendance': ['High', 'Low'],
                                            'Participation': ['Active', 'Passive']})

        # --- Add CPDs to the model ---
        model.add_cpds(cpd_attendance, cpd_participation, cpd_success)

        # --- Validate the model ---
        if model.check_model():
            print("\nModel is valid and has been created successfully.")
        else:
            print("\nModel is invalid. Please check the CPDs.")
            return

        # --- Perform Inference ---
        inference_engine = VariableElimination(model)
        
        # Query for the overall probability of success
        overall_success = inference_engine.query(variables=["CourseSuccess"])
        print("\n--- Overall Probability of Success ---")
        print(overall_success)

        # Query for conditional probability based on evidence
        print("\n--- Conditional Probability Query ---")
        att_evidence = int(input("Enter evidence for Attendance (0 for High, 1 for Low): "))
        part_evidence = int(input("Enter evidence for Participation (0 for Active, 1 for Passive): "))
        
        conditional_success = inference_engine.query(
            variables=["CourseSuccess"],
            evidence={"Attendance": att_evidence, "Participation": part_evidence}
        )
        print("\nResult given the evidence:")
        print(conditional_success)

    except ValueError:
        print("\nInvalid input. Please enter numeric values for probabilities.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()