def safe(v, c, g, col):
    """Check if it's safe to color vertex v with color c."""
    return all(col[neighbor] != c for neighbor in g[v])

def solve_coloring(g, col, m, v=0):
    """Solve the map coloring problem using backtracking."""
    if v == len(g):
        return True
    for c in range(1, m + 1):
        if safe(v, c, g, col):
            col[v] = c
            if solve_coloring(g, col, m, v + 1):
                return True
            col[v] = 0  # Backtrack
    return False

def main():
    try:
        n = int(input("Enter the number of regions: "))
        if n <= 0:
            print("Number of regions must be positive.")
            return
        g = []
        for i in range(n):
            neighbors_str = input(f"Enter neighbors of region {chr(65+i)} (as space-separated numbers, e.g., 1 2 3): ")
            g.append(list(map(int, neighbors_str.split())))
        
        m = int(input("Enter the number of available colors: "))
        col = [0] * n
        
        if solve_coloring(g, col, m):
            print("\nSolution found:")
            for i, c in enumerate(col):
                print(f"Region {chr(65+i)} -> Color {c}")
        else:
            print("\nNo solution exists with the given number of colors.")
    except (ValueError, IndexError) as e:
        print(f"Invalid input. Please enter valid numbers. Error: {e}")

if __name__ == "__main__":
    main()