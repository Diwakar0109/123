def main():
    """A simple bot to suggest the best route from a predefined list."""
    routes = [
        {"name": "Route A", "distance": 12, "traffic": "Heavy", "time": 40},
        {"name": "Route B", "distance": 14, "traffic": "Moderate", "time": 30},
        {"name": "Route C", "distance": 16, "traffic": "Clear", "time": 25}
    ]

    while True:
        print("\n" + "="*10 + " Traffic Bot " + "="*10)
        print("1. Get route recommendation")
        print("2. Exit")
        choice = input("Enter your choice: ")

        if choice == '2':
            break
        elif choice == '1':
            start_location = input("Enter your starting location: ")
            destination = input("Enter your destination: ")

            print("\n--- Available Routes ---")
            for r in routes:
                print(f"{r['name']}: {r['distance']}km | Traffic: {r['traffic']} | Est. Time: {r['time']}min")

            # Find the route with the minimum time
            best_route = min(routes, key=lambda x: x['time'])
            
            print(f"\n--- Best Route Recommendation ---")
            print(f"The best route is {best_route['name']} ({best_route['distance']}km, {best_route['traffic']} traffic, {best_route['time']} minutes).")
            print(f"Follow this route from {start_location} to {destination}.\n")
        else:
            print("Invalid choice. Please try again.")

    print("\nThank you for using the Traffic Bot!")

if __name__ == "__main__":
    main()