import random
import math
import copy

N = 9
B = 3

def calculate_fitness(grid):
    """Calculate the fitness (number of errors) of a Sudoku grid."""
    row_errors = sum(N - len(set(grid[i])) for i in range(N))
    col_errors = sum(N - len(set(grid[j][i] for j in range(N))) for i in range(N))
    return row_errors + col_errors

def fill_initial_grid(puzzle, fixed_mask):
    """Randomly fill the empty cells within each 3x3 box."""
    grid = copy.deepcopy(puzzle)
    for box_row in range(0, N, B):
        for box_col in range(0, N, B):
            box_nums = {grid[box_row+i][box_col+j] for i in range(B) for j in range(B)}
            missing_nums = list(set(range(1, N + 1)) - box_nums)
            random.shuffle(missing_nums)
            for i in range(B):
                for j in range(B):
                    if not fixed_mask[box_row+i][box_col+j]:
                        grid[box_row+i][box_col+j] = missing_nums.pop()
    return grid

def get_neighbor(grid, fixed_mask):
    """Create a neighbor solution by swapping two non-fixed cells in a random box."""
    neighbor_grid = copy.deepcopy(grid)
    # Choose a random 3x3 box
    box_row = random.randint(0, B - 1) * B
    box_col = random.randint(0, B - 1) * B
    
    swappable_cells = [(box_row+i, box_col+j) for i in range(B) for j in range(B) if not fixed_mask[box_row+i][box_col+j]]
    
    if len(swappable_cells) >= 2:
        (r1, c1), (r2, c2) = random.sample(swappable_cells, 2)
        neighbor_grid[r1][c1], neighbor_grid[r2][c2] = neighbor_grid[r2][c2], neighbor_grid[r1][c1]
    
    return neighbor_grid

def solve_with_annealing(puzzle):
    """Solve Sudoku using the simulated annealing algorithm."""
    fixed_mask = [[puzzle[i][j] != 0 for j in range(N)] for i in range(N)]
    
    current_grid = fill_initial_grid(puzzle, fixed_mask)
    current_score = calculate_fitness(current_grid)
    
    temp = 1.0
    cooling_rate = 0.999
    
    while temp > 1e-4 and current_score > 0:
        neighbor_grid = get_neighbor(current_grid, fixed_mask)
        neighbor_score = calculate_fitness(neighbor_grid)
        
        # Acceptance probability
        delta = current_score - neighbor_score
        if delta > 0 or random.random() < math.exp(delta / temp):
            current_grid, current_score = neighbor_grid, neighbor_score
            
        temp *= cooling_rate
        
    return current_grid

def main():
    print("Enter Sudoku puzzle (9 lines, 9 numbers per line, 0 for empty cells):")
    puzzle = [list(map(int, input().split())) for _ in range(N)]
    
    solution = solve_with_annealing(puzzle)
    
    print("\nSolved Sudoku:")
    for row in solution:
        print(*row)

if __name__ == "__main__":
    main()