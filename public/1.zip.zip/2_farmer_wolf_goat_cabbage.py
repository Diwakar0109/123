from collections import deque

def is_valid_state(state):
    """Check if the state is valid (no one gets eaten)."""
    farmer, wolf, goat, cabbage = state
    # Goat and wolf are on the same side without the farmer
    if goat == wolf and farmer != goat:
        return False
    # Goat and cabbage are on the same side without the farmer
    if goat == cabbage and farmer != goat:
        return False
    return True

def get_next_states(state):
    """Generate all possible valid next states from the current state."""
    next_states = []
    farmer_side = state[0]
    # Items that can be moved: Farmer alone (index -1), Wolf (0), Goat (1), Cabbage (2)
    for i in range(-1, 3):
        new_state = list(state)
        # Move farmer
        new_state[0] = 1 - farmer_side
        # Move an item with the farmer
        if i != -1 and state[i+1] == farmer_side:
            new_state[i+1] = 1 - farmer_side
        elif i != -1:
            continue # Can't move an item from the other side
        
        new_state_tuple = tuple(new_state)
        if is_valid_state(new_state_tuple):
            next_states.append(new_state_tuple)
    return next_states

def solve_puzzle(start_state, goal_state):
    """Solve the puzzle using Breadth-First Search (BFS)."""
    queue = deque([(start_state, [start_state])])
    visited = {start_state}
    
    while queue:
        current_state, path = queue.popleft()
        if current_state == goal_state:
            return path
        
        for next_state in get_next_states(current_state):
            if next_state not in visited:
                visited.add(next_state)
                new_path = path + [next_state]
                queue.append((next_state, new_path))
    return None

def main():
    # State is (Farmer, Wolf, Goat, Cabbage)
    # 0 = starting bank, 1 = destination bank
    start = (0, 0, 0, 0)
    goal = (1, 1, 1, 1)
    
    print(f"Solving Farmer-Wolf-Goat-Cabbage puzzle.")
    print(f"Start State (F, W, G, C): {start}")
    print(f"Goal State (F, W, G, C):  {goal}")
    
    solution = solve_puzzle(start, goal)
    
    if solution:
        print("\nSolution Steps:")
        for step in solution:
            print(step)
    else:
        print("\nNo solution found.")

if __name__ == "__main__":
    main()