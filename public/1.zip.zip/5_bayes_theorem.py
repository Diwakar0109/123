def bayes_theorem(p_d, p_t_given_d, p_t_given_nd):
    """
    Calculates the posterior probability P(D|T) using Bayes' Theorem.
    
    Args:
        p_d (float): Prior probability of the disease, P(D).
        p_t_given_d (float): Probability of a positive test given the disease, P(T|D).
        p_t_given_nd (float): Probability of a positive test given no disease, P(T|~D).
        
    Returns:
        float: The posterior probability, P(D|T).
    """
    p_nd = 1 - p_d  # P(~D)
    numerator = p_t_given_d * p_d
    denominator = (p_t_given_d * p_d) + (p_t_given_nd * p_nd)
    
    if denominator == 0:
        return float('nan') # Avoid division by zero
        
    return numerator / denominator

def main():
    try:
        print("Enter probabilities as values between 0 and 1.")
        
        # P(D) - Prior probability of having the disease
        p_d = float(input("Enter the prior probability of the disease, P(D): "))
        
        # P(T|D) - Sensitivity of the test
        p_t_d = float(input("Enter the probability of a positive test given disease, P(T|D) (sensitivity): "))
        
        # P(~T|~D) - Specificity of the test
        specificity = float(input("Enter the probability of a negative test given no disease, P(~T|~D) (specificity): "))
        
        # P(T|~D) is 1 - Specificity
        p_t_nd = 1 - specificity
        
        # Validate inputs
        if not (0 <= p_d <= 1 and 0 <= p_t_d <= 1 and 0 <= specificity <= 1):
             print("\nError: All probability values must be between 0 and 1.")
             return

        posterior_probability = bayes_theorem(p_d, p_t_d, p_t_nd)
        
        print(f"\nThe posterior probability of having the disease given a positive test, P(D|T), is: {posterior_probability:.2%}")
        
    except ValueError:
        print("\nInvalid input. Please enter a valid number.")

if __name__ == "__main__":
    main()