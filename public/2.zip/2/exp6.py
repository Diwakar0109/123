from pgmpy.models import DiscreteBayesianNetwork
from pgmpy.factors.discrete import TabularCPD
from pgmpy.inference import VariableElimination

ah = float(input("P(Attendance=High): "))
pa = float(input("P(Participation=Active): "))
shh = float(input("P(Success|High,Active): "))
shp = float(input("P(Success|High,Passive): "))
slh = float(input("P(Success|Low,Active): "))
slp = float(input("P(Success|Low,Passive): "))

m = DiscreteBayesianNetwork([
    ("Attendance", "CourseSuccess"),
    ("Participation", "CourseSuccess")
])

m.add_cpds(
    TabularCPD("Attendance", 2, [[ah], [1 - ah]]),
    TabularCPD("Participation", 2, [[pa], [1 - pa]]),
    TabularCPD(
        "CourseSuccess", 2,
        [[shh, shp, slh, slp],
         [1 - shh, 1 - shp, 1 - slh, 1 - slp]],
        evidence=["Attendance", "Participation"],
        evidence_card=[2, 2]
    )
)

print("Model valid:", m.check_model())

inf = VariableElimination(m)
print("\nOverall:\n", inf.query(variables=["CourseSuccess"]))

a = int(input("\nAttendance (0=High,1=Low): "))
p = int(input("Participation (0=Active,1=Passive): "))
print("\nConditional:\n", inf.query(variables=["CourseSuccess"],
      evidence={"Attendance": a, "Participation": p}))
