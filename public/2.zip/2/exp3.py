import random, math, copy

N, B = 9, 3
fit = lambda g: sum((N - len(set(g[i])) + N - len(set(g[j][i] for j in range(N))) for i in range(N)))

def fill(p, f):
    g = copy.deepcopy(p)
    for br in range(0, N, B):
        for bc in range(0, N, B):
            nums = list(set(range(1, 10)) - {g[br + i][bc + j] for i in range(B) for j in range(B)})
            random.shuffle(nums)
            for i in range(B):
                for j in range(B):
                    if not f[br + i][bc + j]:
                        g[br + i][bc + j] = nums.pop()
    return g

def neigh(g, f):
    n = []
    for _ in range(10):
        br, bc = random.randint(0, 2) * B, random.randint(0, 2) * B
        c = [(br + i, bc + j) for i in range(B) for j in range(B) if not f[br + i][bc + j]]
        if len(c) >= 2:
            (r1, c1), (r2, c2) = random.sample(c, 2)
            ng = copy.deepcopy(g)
            ng[r1][c1], ng[r2][c2] = ng[r2][c2], ng[r1][c1]
            n.append(ng)
    return n

def anneal(p):
    f = [[p[i][j] != 0 for j in range(N)] for i in range(N)]
    c = fill(p, f)
    cs, t = fit(c), 2.0
    while cs and t > 1e-4:
        for n in neigh(c, f):
            ns = fit(n)
            if ns < cs or random.random() < math.exp((cs - ns) / t):
                c, cs = n, ns
                break
        t *= 0.99
    return c

print("Enter Sudoku (9 lines, 0 for empty):")
p = [list(map(int, input().split())) for _ in range(9)]
for r in anneal(p):
    print(*r)
