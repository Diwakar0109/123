def bayes(p_d, p_t_d, p_t_nd, p_nd):
    return (p_t_d * p_d) / ((p_t_d * p_d) + (p_t_nd * p_nd))

print("Enter probabilities (0–1):")
p_d = float(input("P(D): "))
p_t_d = float(input("P(T|D): "))
spec = float(input("Specificity (P(~T|~D)): "))
p_t_nd, p_nd = 1 - spec, 1 - p_d
prob = bayes(p_d, p_t_d, p_t_nd, p_nd)
print(f"\nP(D|T) = {prob:.2%}")
