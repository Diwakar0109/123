def safe(v, c, g, col):
    return all(col[n] != c for n in g[v])

def solve(g, col, m, v=0):
    if v == len(g):
        return True
    for c in range(1, m + 1):
        if safe(v, c, g, col):
            col[v] = c
            if solve(g, col, m, v + 1):
                return True
            col[v] = 0
    return False

# Input
n = int(input("Regions: "))
g = [list(map(int, input(f"Neighbors of {chr(65 + i)}: ").split())) for i in range(n)]
m = int(input("Colors: "))

col = [0] * n

if solve(g, col, m):
    for i, c in enumerate(col):
        print(f"{chr(65 + i)} → Color {c}")
else:
    print("No solution")


'''Regions: 4
Neighbors of A: 1 2
Neighbors of B: 0 2 3
Neighbors of C: 0 1 3
Neighbors of D: 1 2
Colors: 3'''