from collections import deque

def ok(s):
    f, w, g, c = s
    return not ((g == w and f != g) or (g == c and f != g))

def nxt(s):
    n = []
    f, w, g, c = s
    for i in range(4):
        if i == 0 or s[i] == f:
            ns = list(s)
            ns[0] ^= 1
            if i:
                ns[i] ^= 1
            if ok(ns):
                n.append(tuple(ns))
    return n

def solve(a, b):
    q = deque([(a, [])])
    v = set()
    while q:
        s, p = q.popleft()
        if s == b:
            return p + [s]
        for ns in nxt(s):
            if ns not in v:
                v.add(ns)
                q.append((ns, p + [s]))
    return None

def gi(msg):
    return tuple(map(int, input(msg).split()))

a = gi("Start (F W G C): ")
b = gi("Goal (F W G C): ")
r = solve(a, b)
print("Steps:\n" + "\n".join(map(str, r)) if r else "No solution")
