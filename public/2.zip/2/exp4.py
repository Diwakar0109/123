def main():
    routes = [
        {"name": "Route A", "distance": 12, "traffic": "Heavy", "time": 40},
        {"name": "Route B", "distance": 14, "traffic": "Moderate", "time": 30},
        {"name": "Route C", "distance": 16, "traffic": "Clear", "time": 25}
    ]
    while True:
        c = input("\n=== Traffic Bot ===\n1. Get Route\n2. Exit\nChoice: ")
        if c == '2':
            break
        if c != '1':
            print("Invalid choice.")
            continue
        s = input("Start: ")
        d = input("Destination: ")
        for r in routes:
            print(f"{r['name']}: {r['distance']}km | {r['traffic']} | {r['time']}min")
        best = min(routes, key=lambda x: x['time'])
        print(f"\nBest: {best['name']} ({best['distance']}km, {best['traffic']}, {best['time']}min)")
        print(f"Follow this route from {s} to {d}.\n")
    print("\nThanks for using Traffic Bot!")

if __name__ == "__main__":
    main()
