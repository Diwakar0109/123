import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

X, y = load_digits(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

k_vals, accs = [1, 3, 5, 7], []

for k in k_vals:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train, y_train)
    acc = accuracy_score(y_test, model.predict(X_test))
    accs.append(acc)
    print(f"k={k} → Accuracy={acc:.4f}")

plt.plot(k_vals, accs, 'o-', label="Accuracy")
plt.title("KNN Accuracy vs. k")

plt.xlabel("k")
plt.ylabel("Accuracy")
plt.grid(True)
plt.legend()
plt.show()

best_k = k_vals[np.argmax(accs)]
plt.bar([f"k={best_k}"], [max(accs)], color='skyblue')
plt.ylim(0.9, 1.0)
plt.title(f"Final Accuracy (k={best_k})")
plt.ylabel("Accuracy")
plt.show()
