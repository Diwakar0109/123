import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

data = {
    'Age': np.random.randint(18, 55, 100),
    'Post_p_w': np.random.randint(1, 50, 100),
    'Like_p_w': np.random.randint(20, 500, 100),
    'Shares_p_w': np.random.randint(5, 100, 100)
}

df = pd.DataFrame(data)

scaler = StandardScaler()
scaled_data = scaler.fit_transform(df)

wcss = []
k_values = range(1, 11)

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(scaled_data)
    clusters = kmeans.predict(scaled_data)
    df['Cluster'] = clusters
    wcss.append(kmeans.inertia_)
    if k > 1:
        score = silhouette_score(scaled_data, clusters)
        print(f"Silhouette Score for k={k}: {score:.3f}")

plt.plot(k_values, wcss, marker='o')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of clusters (k)')
plt.ylabel('WCSS')
plt.grid(True)
plt.show()
