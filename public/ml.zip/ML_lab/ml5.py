import os, cv2, numpy as np, seaborn as sns, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score,
                             classification_report,
                             confusion_matrix)

def load(folder, label):
    imgs, lbls = [], []
    for f in os.listdir(folder):
        p = os.path.join(folder, f)
        img = cv2.imread(p, 0)
        if img is not None:
            imgs.append(cv2.resize(img, (100, 100)).flatten())
            lbls.append(label)
    return imgs, lbls

yes, y1 = load("brain_tumor_dataset/yes", 1)
no, y0 = load("brain_tumor_dataset/no", 0)
X = np.array(yes + no)
y = np.array(y1 + y0)

Xtr, Xte, ytr, yte = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y)

model = SVC(kernel='linear', C=1)
model.fit(Xtr, ytr)
yp = model.predict(Xte)

print("Accuracy:", accuracy_score(yte, yp))
print("\nReport:\n", classification_report(yte, yp))

cm = confusion_matrix(yte, yp)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
            xticklabels=["No Tumor", "Tumor"],
            yticklabels=["No Tumor", "Tumor"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()

for i in range(3):
    plt.imshow(Xte[i].reshape(100, 100), cmap="gray")
    plt.title(f"Pred:{yp[i]}  Actual:{yte[i]}")
    plt.show()
