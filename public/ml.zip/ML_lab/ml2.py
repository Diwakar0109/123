import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
import statsmodels.api as sm

df = pd.read_csv("StudentsPerformance.csv")
df.columns = df.columns.str.strip()

for col in ['math score', 'reading score', 'writing score']:
    df[col] = pd.to_numeric(df[col], errors='coerce')

df_encoded = pd.get_dummies(df, drop_first=True)

X = df_encoded.drop(['math score'], axis=1)
y = df_encoded['math score']

X = X.apply(pd.to_numeric, errors='coerce').astype(float)
X = X.dropna()
y = y.loc[X.index]

X_const = sm.add_constant(X)
model = sm.OLS(y, X_const).fit()
print(model.summary())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
reg = LinearRegression().fit(X_train, y_train)
y_pred = reg.predict(X_test)

mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"\nMean Squared Error : {mse:.2f}")
print(f"R2 Score : {r2:.2f}")

plt.figure(figsize=(7, 5))
sns.regplot(x=y_test, y=y_pred, scatter_kws={'color': 'gray'}, line_kws={'color': 'red'})
plt.xlabel("Actual Math Score")
plt.ylabel("Predicted Math Score")
plt.title("Actual vs Predicted Math Score")
plt.grid(True)
plt.show()
