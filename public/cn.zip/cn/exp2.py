def xor(a, b): return ''.join(str(int(a[i]) ^ int(b[i])) for i in range(1, len(b)))
def mod2(d, k):
    p, t = len(k), d[:len(k)]
    while p < len(d):
        t = xor(k if t[0] == '1' else '0'*p, t) + d[p]
        p += 1
    return xor(k if t[0] == '1' else '0'*p, t)
def encode(d, k):
    ad = d + '0'*(len(k)-1)
    r = mod2(ad, k)
    return ad, r, d + r
def decode(d, k):
    r = mod2(d, k)
    return r, r == '0'*(len(k)-1)
print("---CRC---")
d = input("Data: ")
k = input("Key: ")
ad, r, td = encode(d, k)
print("Appended:", ad, "\nRemainder:", r, "\nSent:", td)

rr, ok = decode(td, k)
print("Received:", td, "\nRemainder:", rr, "\nError:", "No" if ok else "Yes")
# Checksum
def chk(d):
    s = sum(d)
    while s >> 8: s = (s & 0xFF) + (s >> 8)
    return ~s & 0xF
def verify(d, c):
    t = sum(d) + c
    while t >> 8: t = (t & 0xFF) + (t >> 8)
    return t == 0xFF
print("\n---Checksum---")
h = [int(x, 16) for x in input("Hex bytes: ").split()]
c = chk(h)
print("Checksum:", hex(c))
print("Error:", "No" if verify(h, c) else "Yes")
