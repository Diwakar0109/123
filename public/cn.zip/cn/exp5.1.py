import heapq
INF = 999
def dijkstra(graph, start):
    n = len(graph)
    dist = [INF] * n
    dist[start] = 0
    pq = [(0, start)] 
    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]:
            continue
        for v in range(n):
            if graph[u][v] != INF: 
                new_dist = d + graph[u][v]
                if new_dist < dist[v]:
                    dist[v] = new_dist
                    heapq.heappush(pq, (new_dist, v))
    return dist
n = int(input("Enter number of nodes: "))
print("Enter the cost matrix (use 999 for no link):")
graph = [list(map(int, input(f"Row {i+1}: ").split())) for i in range(n)]
for i in range(n):
    result = dijkstra(graph, i)
    print(f"\nShortest paths from Node {i+1}:")
    for j in range(n):
        print(f"To Node {j+1}: {result[j]}")
