import socket
s = socket.socket()
s.bind(('localhost', 5555))
s.listen(1)
c, _ = s.accept()
while True:
    data = c.recv(1024).decode()
    if not data: break
    print("Client:", data)
    c.send(input("You: ").encode())
