import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind(('localhost', 6666))
while True:
    data, addr = s.recvfrom(1024)
    print("Client:", data.decode())
    s.sendto(input("You: ").encode(), addr)
