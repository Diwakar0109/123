import socket
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
addr = ('localhost', 6666)
while True:
    s.sendto(input("You: ").encode(), addr)
    print("Server:", s.recvfrom(1024)[0].decode())
