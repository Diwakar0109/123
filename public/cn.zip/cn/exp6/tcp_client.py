import socket
c = socket.socket()
c.connect(('localhost', 5555))
while True:
    c.send(input("You: ").encode())
    print("Server:", c.recv(1024).decode())
