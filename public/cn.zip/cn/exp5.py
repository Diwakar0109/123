INF = 999
n = int(input("Enter number of nodes: "))
print("Enter the cost matrix (use 999 for infinity):")
graph = [list(map(int, input(f"Row {i+1}: ").split())) for i in range(n)]
distance = [row[:] for row in graph]
for k in range(n):
    for i in range(n):
        for j in range(n):
            if distance[i][j] > distance[i][k] + distance[k][j]:
                distance[i][j] = distance[i][k] + distance[k][j]
print("\nFinal Distance Vector Routing Table:")
for i in range(n):
    print(f"From Node {i+1}: {distance[i]}")
