import simpy
def task(env, name, st, server):
    yield env.timeout(st)  
    print(f"{name} arrived at {env.now}")
    with server.request() as req:
        yield req
        print(f"{name} started at {env.now}")
        yield env.timeout(4)
        print(f"{name} finished at {env.now}")
env = simpy.Environment()
server = simpy.Resource(env, capacity=1)
env.process(task(env, "cloddel t", 3, server))
env.process(task(env, "cloddel z", 2, server))
env.process(task(env, "cloddel 3", 1, server))
env.run()
