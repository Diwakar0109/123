import sys
def mapper():
    # Read lines from standard input
    for line in sys.stdin:
        words = line.strip().split()
        for word in words:
            if word:
                print(f"{word}\t1")  
def reducer():
    current_word = None
    current_count = 0
    for line in sys.stdin:
        parts = line.strip().split('\t')
        if len(parts) != 2:
            continue
        word, count = parts
        count = int(count)
        if current_word == word:
            current_count += count
        else:
            if current_word:
                print(f"{current_word}\t{current_count}")
            current_word = word
            current_count = count
    if current_word:
        print(f"{current_word}\t{current_count}")
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python wordcount.py [mapper|reducer]")
        sys.exit(1)
    mode = sys.argv[1]
    if mode == "mapper":
        mapper()
    elif mode == "reducer":
        reducer()
    else:
        print("Invalid mode. Use 'mapper' or 'reducer'.")
        sys.exit(1)


'''1st create txt file as input.txt 
to RUN : cat input.txt | python exp7.py mapper | sort | python exp7.py reducer   '''