from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

texts, labels = [], []

with open("6.txt") as f:
    for line in f:
        t, l = line.strip().split("|")
        texts.append(t)
        labels.append(int(l))

vec = CountVectorizer()
X = vec.fit_transform(texts)

model = MultinomialNB()
model.fit(X, labels)

test = vec.transform(["I love this"])
print(model.predict(test))