from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression

q1, q2, y = [], [], []

with open("2.txt") as f:
    for line in f:
        a, b, c = line.strip().split("|")
        q1.append(a)
        q2.append(b)
        y.append(int(c))

vec = CountVectorizer()
X = vec.fit_transform(q1 + q2)

model = LogisticRegression()
model.fit(X[:10], y)

print("Model trained")