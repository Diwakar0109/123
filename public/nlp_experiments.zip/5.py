trans = {}

with open("5.txt") as f:
    for line in f:
        eng, tam = line.strip().split(" ", 1)
        trans[eng] = tam

word = input("Enter word: ")
print(trans.get(word, "Not found"))