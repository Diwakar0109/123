import nltk

grammar = "NP: {<DT>?<JJ>*<NN>}"
cp = nltk.RegexpParser(grammar)

with open("4.txt") as f:
    for line in f:
        words = nltk.word_tokenize(line)
        tags = nltk.pos_tag(words)
        tree = cp.parse(tags)
        print(tree)