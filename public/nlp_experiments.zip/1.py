from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

ps = PorterStemmer()

with open("1.txt") as f:
    for line in f:
        words = word_tokenize(line.strip())
        stems = [ps.stem(w) for w in words]
        print(stems)