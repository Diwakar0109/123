from collections import defaultdict

model = defaultdict(list)

with open("3.txt") as f:
    for line in f:
        words = line.strip().split()
        for i in range(len(words)-1):
            model[words[i]].append(words[i+1])

word = input("Enter word: ")
print(model[word])