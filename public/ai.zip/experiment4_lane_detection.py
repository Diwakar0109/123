import cv2
import numpy as np

img = cv2.imread("road.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray, 50, 150)

mask = np.zeros_like(edges)
h, w = edges.shape
polygon = np.array([[(0,h),(w,h),(w//2,h//2)]])
cv2.fillPoly(mask, polygon, 255)

roi = cv2.bitwise_and(edges, mask)

lines = cv2.HoughLinesP(roi, 1, np.pi/180, 50, minLineLength=100, maxLineGap=50)

if lines is not None:
    for line in lines:
        x1,y1,x2,y2 = line[0]
        cv2.line(img, (x1,y1), (x2,y2), (0,255,0), 3)

cv2.imshow("Lane", img)
cv2.waitKey(0)
