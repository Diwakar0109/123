import cv2

img = cv2.imread("image.jpg")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
blur = cv2.GaussianBlur(gray, (5,5), 0)
edges = cv2.Canny(blur, 50, 150)

contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

for cnt in contours:
    approx = cv2.approxPolyDP(cnt, 0.02*cv2.arcLength(cnt, True), True)
    x,y,w,h = cv2.boundingRect(approx)

    shape = "Unknown"
    if len(approx) == 3: shape = "Triangle"
    elif len(approx) == 4: shape = "Rectangle"
    elif len(approx) > 4: shape = "Circle"

    cv2.putText(img, shape, (x,y), 1, 1, (0,255,0), 2)

cv2.imshow("Output", img)
cv2.waitKey(0)
