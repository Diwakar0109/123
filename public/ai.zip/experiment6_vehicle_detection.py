import torch
import cv2
from torchvision import models, transforms

model = models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
model.eval()

img = cv2.imread("traffic.jpg")
transform = transforms.ToTensor()
img_tensor = transform(img)

with torch.no_grad():
    outputs = model([img_tensor])

count = 0
for box, label, score in zip(outputs[0]['boxes'], outputs[0]['labels'], outputs[0]['scores']):
    if score > 0.5 and label in [3,6,8]:
        count += 1
        x1,y1,x2,y2 = map(int, box)
        cv2.rectangle(img, (x1,y1), (x2,y2), (0,255,0), 2)

print("Vehicle Count:", count)
cv2.imshow("Vehicles", img)
cv2.waitKey(0)
