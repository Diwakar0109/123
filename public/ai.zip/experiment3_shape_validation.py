import cv2
import numpy as np

img = cv2.imread("shape.png")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

edges = cv2.Canny(gray, 50, 150)

corners = cv2.cornerHarris(gray, 2, 3, 0.04)
img[corners > 0.01 * corners.max()] = [0,0,255]

cv2.imshow("Edges", edges)
cv2.imshow("Corners", img)
cv2.waitKey(0)
