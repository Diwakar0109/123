import kagglehub, pandas as pd, numpy as np, tensorflow as tf, matplotlib.pyplot as plt, os

path = kagglehub.dataset_download("datamunge/sign-language-mnist")
train = pd.read_csv(os.path.join(path,"sign_mnist_train.csv"))
test = pd.read_csv(os.path.join(path,"sign_mnist_test.csv"))

ytr, yte = train['label'].values, test['label'].values
xtr = train.drop('label', axis=1).values.reshape(-1,28,28,1)/255.0
xte = test.drop('label', axis=1).values.reshape(-1,28,28,1)/255.0

m = tf.keras.Sequential([
  tf.keras.layers.Conv2D(32,3,activation='relu',input_shape=(28,28,1)),
  tf.keras.layers.MaxPooling2D(2),
  tf.keras.layers.Conv2D(64,3,activation='relu'),
  tf.keras.layers.MaxPooling2D(2),
  tf.keras.layers.Flatten(),
  tf.keras.layers.Dense(128,activation='relu'),
  tf.keras.layers.Dropout(0.5),
  tf.keras.layers.Dense(26,activation='softmax')
])

m.compile(optimizer='adam',loss='sparse_categorical_crossentropy',metrics=['accuracy'])
h = m.fit(xtr,ytr,epochs=5,validation_data=(xte,yte),verbose=1)
print(f"\n✅ Test Accuracy: {m.evaluate(xte,yte,verbose=0)[1]*100:.2f}%")

plt.figure(figsize=(10,4))
for i,k in enumerate(['accuracy','loss']):
  plt.subplot(1,2,i+1); plt.plot(h.history[k]); plt.plot(h.history[f'val_{k}']); plt.title(k.capitalize()); plt.legend(['Train','Val'])
plt.show()

i=np.random.randint(len(xte))
p=np.argmax(m.predict(xte[i][None]))
plt.imshow(xte[i].squeeze(),cmap='gray'); plt.title(f"Pred:{chr(p+65)}, True:{chr(yte[i]+65)}"); plt.axis('off'); plt.show()