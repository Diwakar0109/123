import socket

# Create TCP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(('localhost', 12345))

while True:
    # Send message to server
    msg = input("Client: ")
    client_socket.send(msg.encode())
    if msg.lower() == 'bye':
        break

    # Receive message from server
    data = client_socket.recv(1024).decode()
    if not data:
        break

    print("Server:", data)
    if data.lower() == 'bye':
        break

client_socket.close()
print("Client connection closed.")