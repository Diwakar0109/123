import socket

# Create UDP socket
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Bind to localhost and port 54321
server_socket.bind(('localhost', 54321))
print("UDP Server is ready to receive messages...")

while True:
    # Receive message from client
    data, addr = server_socket.recvfrom(1024)
    message = data.decode()
    print("Client:", message)

    # Check for exit condition
    if message.lower() == 'bye':
        print("Client ended chat.")
        break

    # Send message to client
    msg = input("Server: ")
    server_socket.sendto(msg.encode(), addr)
    if msg.lower() == 'bye':
        break

print("Server connection closed.")