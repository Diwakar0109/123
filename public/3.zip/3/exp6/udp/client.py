import socket

# Create UDP socket
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

while True:
    # Send message to server
    msg = input("Client: ")
    client_socket.sendto(msg.encode(), ('localhost', 54321))
    if msg.lower() == 'bye':
        break

    # Receive message from server
    data, _ = client_socket.recvfrom(1024)
    print("Server:", data.decode())

    if data.decode().lower() == 'bye':
        break

print("Client connection closed.")