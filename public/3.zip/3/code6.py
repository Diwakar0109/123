import pandas as pd, numpy as np, matplotlib.pyplot as plt, seaborn as sns
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import TruncatedSVD

books = pd.DataFrame({'book_id':[1,2,3,4,5],
't':['The Alchemist','The Power of Habit',"Harry Potter","Pride & Prejudice",'Atomic Habits']})
ratings = pd.DataFrame({'u':[1,1,1,2,2,3,3,4,4,5],
'b':[1,2,3,2,4,1,5,3,4,5],
'r':[5,4,4,5,3,4,5,4,5,3]})

mat = ratings.pivot(index='u',columns='b',values='r').fillna(0)
svd = TruncatedSVD(2,random_state=42)
latent = svd.fit_transform(mat)
sim = cosine_similarity(svd.components_.T)

def rec(title):
    i = books[books.t==title].index[0]
    s = sorted(list(enumerate(sim[i])), key=lambda x:x[1], reverse=True)[1:4]
    print(f"\nTop 3 for '{title}':")
    for j,score in s: print(f"👉 {books.t[j]} ({score:.2f})")

for b in books.t: rec(b)

sns.heatmap(sim,annot=True,cmap='YlGnBu',
xticklabels=books.t,yticklabels=books.t)
plt.title("Book Similarity");plt.show()
